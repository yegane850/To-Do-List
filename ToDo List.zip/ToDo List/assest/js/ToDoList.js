let $ = document;
let inputElem = $.querySelector("input");
let addTodoForm = $.querySelector(".add");
let todoUlElem = $.querySelector(".todos");
let deleteAllButton = $.querySelector("#delete-all");
let todoCountElem = $.querySelector("#todo-count");

function updateTodoCount() {
  let count = todoUlElem.children.length;
  todoCountElem.innerHTML = `You have ${count} pending tasks`;
}

function showAlert(message) {
  alert(message);
}

function addNewTodo(newTodoValue) {
  let newTodoLi = $.createElement("li");
  newTodoLi.className =
    "list-group-item d-flex justify-content-between align-items-center";

  let newTodoTitleSpan = $.createElement("span");
  newTodoTitleSpan.innerHTML = newTodoValue;

  let newTodoTrash = $.createElement("i");
  newTodoTrash.className = "fa fa-trash-o delete";

  newTodoTrash.addEventListener("click", function (event) {
    if (confirm("آیا مطمئن هستید که می‌خواهید این مورد را حذف کنید؟")) {
      event.target.parentElement.remove();
      updateTodoCount();
      showAlert("مورد حذف شد.");
    }
  });

  newTodoLi.append(newTodoTitleSpan, newTodoTrash);
  todoUlElem.append(newTodoLi);
  updateTodoCount();
  showAlert("مورد به لیست اضافه شد.");
}

addTodoForm.addEventListener("submit", function (event) {
  event.preventDefault();
});

inputElem.addEventListener("keydown", function (event) {
  let newTodoValue = event.target.value.trim();

  if (event.keyCode === 13) {
    if (newTodoValue) {
      inputElem.value = "";
      addNewTodo(newTodoValue);
    }
  }
});

deleteAllButton.addEventListener("click", function () {
  if (confirm("آیا مطمئن هستید که می‌خواهید همه موارد را حذف کنید؟")) {
    todoUlElem.innerHTML = "";
    updateTodoCount();
    showAlert("همه موارد حذف شدند.");
  }
});
updateTodoCount();
